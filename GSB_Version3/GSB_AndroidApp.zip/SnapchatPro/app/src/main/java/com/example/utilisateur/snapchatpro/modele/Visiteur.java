package com.example.utilisateur.snapchatpro.modele;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Samy on 27/03/2018.
 */

public class Visiteur extends AppCompatActivity {
    private Integer numVis;
    private String nom;
    private String prenom;


    public Visiteur(Integer numVis,String nom, String prenom ) {
        this.numVis = numVis;
        this.nom = nom;
        this.prenom = prenom;

    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    public Integer getNumVis() {
        return numVis;
    }



    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setNumVis(int numVis) {
        this.numVis=numVis;
    }

    public void setNom(String nom) {
          this.nom=nom;
    }

    public void setPrenom(String prenom) {
        this.prenom=prenom;
    }

}
