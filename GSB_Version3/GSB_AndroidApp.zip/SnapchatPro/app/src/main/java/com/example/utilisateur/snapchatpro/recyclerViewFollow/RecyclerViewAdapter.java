package com.example.utilisateur.snapchatpro.recyclerViewFollow;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.utilisateur.snapchatpro.R;
import com.example.utilisateur.snapchatpro.modele.UserInformation;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

/**
 * Created by Samy on 20/03/2018.
 */

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewHolders> {

   private List<UsersObject> usersList;
   private Context context ;

   public RecyclerViewAdapter(List<UsersObject> usersList, Context context){
       this.usersList=usersList;
       this.context=context;

   }
    @Override
    public RecyclerViewHolders onCreateViewHolder(ViewGroup parent, int viewType) {
        View layoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_follow_item,null);
        RecyclerViewHolders rcv= new RecyclerViewHolders(layoutView);
       return rcv;
    }

    @Override
    public void onBindViewHolder(final RecyclerViewHolders holder, int position) {
       holder.mEmail.setText(usersList.get(position).getEmail());

       if(UserInformation.listFollowing.contains(usersList.get(holder.getLayoutPosition()).getUid())){
            holder.mFollow.setText("following");
        }else{
           holder.mFollow.setText("follow");

       }

       //add db et remove db
        holder.mFollow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
                if(!UserInformation.listFollowing.contains(usersList.get(holder.getLayoutPosition()).getUid())){
                    holder.mFollow.setText("following");
                    FirebaseDatabase.getInstance().getReference().child("users").child(userId).child("following").child(usersList.get(holder.getLayoutPosition()).getUid()).setValue(true);
                } else {
                    FirebaseDatabase.getInstance().getReference().child("users").child(userId).child("following").child(usersList.get(holder.getLayoutPosition()).getUid()).removeValue();


                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.usersList.size();
    }

    //choisie ce qu'on place dans le recyler view et la controle


}
