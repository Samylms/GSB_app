package com.example.utilisateur.snapchatpro.view;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.utilisateur.snapchatpro.R;
import com.example.utilisateur.snapchatpro.messaging.Messagerie;
import com.example.utilisateur.snapchatpro.modele.Crud_Fragment;
import com.example.utilisateur.snapchatpro.modele.Visiteur;
import com.example.utilisateur.snapchatpro.outils.Api;
import com.example.utilisateur.snapchatpro.outils.RequestHandler;
import com.example.utilisateur.snapchatpro.uploadfile.ActivityM;
import com.example.utilisateur.snapchatpro.uploadfile.UploadFile_Activity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class IdentificationActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;

    private static final int CODE_POST_REQUEST = 1024;
    private static final int CODE_GET_REQUEST = 1025;
    Visiteur visiteur;


    EditText etNom, etPrenom, etAge, etnumPermis;
    List<Visiteur> visiteurList;
    ProgressBar progressBar;
    ListView listView;
     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_identification);


         setupNavigationDrawerMenu();

         mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer);
         mToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.open, R.string.close);

         NavigationView mNavigationView = (NavigationView) findViewById(R.id.nvView);
         mNavigationView.setNavigationItemSelectedListener(this);
         mNavigationView.bringToFront();

         mToggle.syncState();
         getSupportActionBar().setDisplayHomeAsUpEnabled(true);


         etNom = (EditText) findViewById(R.id.txtNom);
        etPrenom = (EditText) findViewById(R.id.txtPrenom);
         listView = (ListView) findViewById(R.id.listViewVisiteurs);

         Button mChoixVehic = (Button) findViewById(R.id.choixVehic);
         Button mRechVis = (Button) findViewById(R.id.btnRechVis);


        visiteurList = new ArrayList<>();

        mChoixVehic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                  Intent intent = new Intent(getApplicationContext(), ReservationChooseCarActivity.class);

                intent.putExtra("nom", etNom.getText().toString());
                intent.putExtra("prenom", etPrenom.getText().toString());
                startActivity(intent);

            }
        });

        mRechVis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 readVisiteur();
            }
        });
    }



    private void setupNavigationDrawerMenu() {
        NavigationView navigationView = (NavigationView) findViewById(R.id.nvView);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        navigationView.setNavigationItemSelectedListener(this);


        mDrawerLayout.addDrawerListener(mToggle);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mToggle.onOptionsItemSelected(item)) {
            return false;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        closeDrawer();


        switch (item.getItemId()) {
            case R.id.con:
                Intent intent0 = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent0);
                break;

            case R.id.chat:
                Intent intent1 = new Intent(getApplicationContext(), Messagerie.class);
                startActivity(intent1);
                break;

            case R.id.carcrash:
                Intent intent2 = new Intent(getApplicationContext(), UploadFile_Activity.class);
                startActivity(intent2);
                break;

            case R.id.photo:
                Intent intent3 = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent3);
                break;

            case R.id.register:
                Intent intent4 = new Intent(getApplicationContext(), RegistrationActivity.class);
                startActivity(intent4);
                break;
            case R.id.gestionVehicule:
                Intent intent5 = new Intent(getApplicationContext(), Crud_Fragment.class);
                startActivity(intent5);
                break;

        }
        item.setCheckable(true);
        mDrawerLayout.closeDrawers();

        return true;
    }

    private void closeDrawer() {
        mDrawerLayout.closeDrawer(GravityCompat.START);
    }

    private void showDrawer() {
        mDrawerLayout.openDrawer(GravityCompat.START);
    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START))
            closeDrawer();
        else
            super.onBackPressed();
    }







    private void readVisiteur() {
        IdentificationActivity.PerformNetworkRequest request = new PerformNetworkRequest(Api.URL_RECHERCHE_VISITEUR, null, CODE_GET_REQUEST);
        request.execute();
    }

    private void refreshVisiteurList(JSONArray visiteurs) throws JSONException {
        visiteurList.clear();

        for (int i = 0; i < visiteurs.length(); i++) {
            JSONObject obj = visiteurs.getJSONObject(i);

            visiteurList.add(new Visiteur(
                    obj.getInt("numVis"),
                    obj.getString("nom"),
                    obj.getString("prenom")

            ));
        }



        IdentificationActivity.VisiteurAdapter adapter = new VisiteurAdapter(visiteurList);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {


            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Visiteur item = (Visiteur) adapter.getItem(i);

                Intent intent = new Intent(IdentificationActivity.this, ReservationChooseCarActivity.class);

                //recuperer les variable et les afficher dans une seconde activité
                intent.putExtra("numVis", String.valueOf("Id du visiteur : "+item.getNumVis()));
                intent.putExtra("nom", item.getNom());
                intent.putExtra("prenom", item.getPrenom());




                startActivity(intent);
            }
        });
    }



    // Les trois types utilisés par une tâche asynchrone sont les suivants: params,progress,result : Void,Void,String
    private class PerformNetworkRequest extends AsyncTask<Void, Void, String> {
        String url;
        HashMap<String, String> params;
        int requestCode;


        PerformNetworkRequest(String url, HashMap<String, String> params, int requestCode) {
            this.url = url;
            this.params = params;
            this.requestCode = requestCode;
        }


        //invoquée sur le thread de l'interface utilisateur avant l'exécution de la tâche.
        // Cette étape est normalement utilisée pour configurer la tâche,
        // par exemple en affichant une barre de progression dans l'interface utilisateur.
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        //invoquée sur le thread de l'interface utilisateur après la fin du calcul de l'arrière-plan.
        // Le résultat du calcul de l'arrière-plan est passé à cette étape en tant que paramètre.
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
             try {

                JSONObject object = new JSONObject(s);

                if (!object.getBoolean("error")) {
                    Toast.makeText(getApplicationContext(), object.getString("message"), Toast.LENGTH_SHORT).show();
                    refreshVisiteurList(object.getJSONArray("visiteurs"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }


        //invoquée sur le thread d'arrière-plan immédiatement après la onPreExecute()fin de l'exécution.
// Cette étape est utilisée pour effectuer un calcul en arrière-plan qui peut prendre beaucoup de temps.
// Les paramètres de la tâche asynchrone sont transmis à cette étape.
// Le résultat du calcul doit être retourné par cette étape et sera renvoyé à la dernière étape.
        @Override
        protected String doInBackground(Void... voids) {
            RequestHandler requestHandler = new RequestHandler();

            if (requestCode == CODE_POST_REQUEST)
                return requestHandler.sendPostRequest(url, params);


            if (requestCode == CODE_GET_REQUEST)
                return requestHandler.sendGetRequest(url);

            return null;
        }
    }


    //pour afficher vehicule dans un listview
    class VisiteurAdapter extends ArrayAdapter<Visiteur> {
        List<Visiteur> visiteurList;


        VisiteurAdapter(List<Visiteur> visiteurList) {
            super(IdentificationActivity.this, R.layout.layout_visiteur_list, visiteurList);
            this.visiteurList = visiteurList;
        }


        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = getLayoutInflater();
            View listViewItem = inflater.inflate(R.layout.layout_visiteur_list, null, true);

            TextView textViewNumVis = listViewItem.findViewById(R.id.textViewNumVis2);
            TextView textViewName = listViewItem.findViewById(R.id.textViewNom2);
            TextView textViewType = listViewItem.findViewById(R.id.textViewPrenom2);

            TextView textViewSelect = listViewItem.findViewById(R.id.textViewChoisir2);

            final Visiteur visiteur = visiteurList.get(position);

            textViewNumVis.setText(String.valueOf("Id du visiteur : "+visiteur.getNumVis()));
            textViewName.setText(visiteur.getNom());
            textViewType.setText(visiteur.getPrenom());

            textViewSelect.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });


            return listViewItem;
        }


    }
}



