package com.example.utilisateur.snapchatpro.view;

   import android.app.ProgressDialog;
   import android.content.Intent;
   import android.graphics.Path;
   import android.os.AsyncTask;
   import android.support.v7.app.AppCompatActivity;
   import android.os.Bundle;


   import android.view.LayoutInflater;
   import android.view.View;
   import android.view.ViewGroup;
   import android.widget.AdapterView;
   import android.widget.ArrayAdapter;
   import android.widget.ListView;
   import android.widget.Spinner;
   import android.widget.TextView;
   import android.widget.Toast;


   import com.android.volley.RequestQueue;
   import com.android.volley.Response;
   import com.android.volley.VolleyError;
   import com.android.volley.toolbox.StringRequest;
   import com.android.volley.toolbox.Volley;
   import com.example.utilisateur.snapchatpro.R;
   import com.example.utilisateur.snapchatpro.modele.OptionVehicule;
    import com.example.utilisateur.snapchatpro.outils.Api;
   import com.example.utilisateur.snapchatpro.outils.RequestHandler;

   import org.json.JSONArray;
   import org.json.JSONException;
   import org.json.JSONObject;

   import java.util.ArrayList;
   import java.util.HashMap;
   import java.util.List;

   import static com.example.utilisateur.snapchatpro.R.layout.layout_option_vehicule;


public class PayeActivity extends AppCompatActivity {



    TextView affPrix,affLibelle;

    private ProgressDialog progDial;

    List<OptionVehicule> optionList;
    ListView listViewOption;
    private static final int CODE_POST_REQUEST = 1024;
    private static final int CODE_GET_REQUEST = 1025;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
        setContentView(R.layout.activity_paye);


        TextView textViewName2 = findViewById(R.id.txtMarque2);
        TextView textViewType2 = findViewById(R.id.txtType2);
        textViewName2.setText(getIntent().getExtras().getString("libelle"));
        textViewType2.setText(getIntent().getExtras().getString("type"));


        listViewOption = (ListView) findViewById(R.id.listViewOption);



        progDial = new ProgressDialog(PayeActivity.this);
        progDial.setMessage("loading");
        progDial.setCancelable(false);
        progDial.setCanceledOnTouchOutside(false);

        optionList = new ArrayList<>();

        readOption();

     }


    private void readOption() {
        PayeActivity.PerformNetworkRequest request = new PerformNetworkRequest(Api.URL_READ_SPINNER_LIBELLE, null, CODE_GET_REQUEST);
        request.execute();
    }


    private void refreshOptionList(JSONArray options) throws JSONException {
        optionList.clear();

        for (int i = 0; i < options.length(); i++) {
            JSONObject obj = options.getJSONObject(i);

            optionList.add(new OptionVehicule(
                    obj.getInt("idMarque"),
                    obj.getString("libelle"),
                    obj.getString("type"),
                    obj.getInt("libre"),
                    obj.getString("libelle2"),
                    (float) obj.getDouble("prix")
            ));
        }




        PayeActivity.OptionAdapter adapter = new OptionAdapter(optionList);
        listViewOption.setAdapter(adapter);
        listViewOption.setOnItemClickListener(new AdapterView.OnItemClickListener() {


            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

            /*    OptionVehicule item = (OptionVehicule) adapter.getItem(i);

                Intent intent = new Intent(PayeActivity.this, ReservationChooseCarActivity.class);

                //recuperer les variable et les afficher dans une seconde activité
                intent.putExtra("nom", item.getNom());
                intent.putExtra("prenom", item.getPrenom());

                startActivity(intent);*/
            }
        });
    }



    // Les trois types utilisés par une tâche asynchrone sont les suivants: params,progress,result : Void,Void,String
    private class PerformNetworkRequest extends AsyncTask<Void, Void, String> {
        String url;
        HashMap<String, String> params;
        int requestCode;


        PerformNetworkRequest(String url, HashMap<String, String> params, int requestCode) {
            this.url = url;
            this.params = params;
            this.requestCode = requestCode;
        }


        //invoquée sur le thread de l'interface utilisateur avant l'exécution de la tâche.
        // Cette étape est normalement utilisée pour configurer la tâche,
        // par exemple en affichant une barre de progression dans l'interface utilisateur.
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        //invoquée sur le thread de l'interface utilisateur après la fin du calcul de l'arrière-plan.
        // Le résultat du calcul de l'arrière-plan est passé à cette étape en tant que paramètre.
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {

                JSONObject object = new JSONObject(s);

                if (!object.getBoolean("error")) {
                    Toast.makeText(getApplicationContext(), object.getString("message"), Toast.LENGTH_SHORT).show();
                    refreshOptionList(object.getJSONArray("options"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }


        //invoquée sur le thread d'arrière-plan immédiatement après la onPreExecute()fin de l'exécution.
// Cette étape est utilisée pour effectuer un calcul en arrière-plan qui peut prendre beaucoup de temps.
// Les paramètres de la tâche asynchrone sont transmis à cette étape.
// Le résultat du calcul doit être retourné par cette étape et sera renvoyé à la dernière étape.
        @Override
        protected String doInBackground(Void... voids) {
            RequestHandler requestHandler = new RequestHandler();

            if (requestCode == CODE_POST_REQUEST)
                return requestHandler.sendPostRequest(url, params);


            if (requestCode == CODE_GET_REQUEST)
                return requestHandler.sendGetRequest(url);

            return null;
        }
    }

    //pour afficher vehicule dans un listview
    class OptionAdapter extends ArrayAdapter<OptionVehicule> {
        List<OptionVehicule> optionList;


        OptionAdapter(List<OptionVehicule> optionList) {
            super(PayeActivity.this, layout_option_vehicule, optionList);
            this.optionList = optionList;
        }


        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = getLayoutInflater();
            View listViewItem = inflater.inflate(layout_option_vehicule, null, true);

            TextView textViewName = listViewItem.findViewById(R.id.textViewLibelle);
            TextView textViewType = listViewItem.findViewById(R.id.textViewPrix);

            TextView textViewSelect = listViewItem.findViewById(R.id.textViewPayer);

            final OptionVehicule option = optionList.get(position);

            textViewName.setText(option.getLibelle());
            textViewType.setText(Double.toString(option.getPrix())+" $");

            textViewSelect.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });


            return listViewItem;
        }


    }
}








