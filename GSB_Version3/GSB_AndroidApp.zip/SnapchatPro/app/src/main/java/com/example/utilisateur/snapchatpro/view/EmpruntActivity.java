package com.example.utilisateur.snapchatpro.view;

import android.app.DatePickerDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.utilisateur.snapchatpro.R;
import com.example.utilisateur.snapchatpro.outils.Api;
import com.example.utilisateur.snapchatpro.outils.RequestHandler;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

/**
 * Created by Samy on 17/04/2018.
 */

public class EmpruntActivity extends AppCompatActivity  {


    private static final int CODE_GET_REQUEST = 1024;
    private static final int CODE_POST_REQUEST = 1025;

     private TextView mDisplayDep,mDisplayArr, etDateArr,etDateDep;

    private  Button mChoixVehic  ;


    private EditText etnoImmat,etNumVis;

    DatePicker dpStartDate;
    DatePickerDialog picker;

    // calender class's instance and get current date , month and year from calender
    final Calendar c = Calendar.getInstance();
    int mYear = c.get(Calendar.YEAR); // current year
    int mMonth = c.get(Calendar.MONTH); // current month
    int mDay = c.get(Calendar.DAY_OF_MONTH); // current day
    // date picker dialog

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emprunt);

        etDateDep = (TextView) findViewById(R.id.tvDateDep);
        etDateArr = (TextView) findViewById(R.id.tvDateArr);

         mChoixVehic = (Button) findViewById(R.id.btnReserver);
        etnoImmat = (EditText) findViewById(R.id.etNoImmat);
        etNumVis = (EditText) findViewById(R.id.etNumVis);
        dpStartDate = (DatePicker) findViewById(R.id.dpStartDate);





        mChoixVehic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createEmprunt();
            }
        });



        etDateDep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void  onClick(View view)  {

                picker = new DatePickerDialog(EmpruntActivity.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {

                                // set day of month , month and year value in the edit text
                                etDateDep.setText(String.valueOf(dayOfMonth) + ("/") +(monthOfYear + 1) + ("/") + year);
                            }
                        }, mYear, mMonth, mDay);
                 picker.show();
             }
        });

        etDateArr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void  onClick(View view)  {

                picker = new DatePickerDialog(EmpruntActivity.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                // set day of month , month and year value in the edit text
                                etDateArr.setText(String.valueOf(dayOfMonth) + "/" + (monthOfYear + 1) + "/" + year);

                             }
                             }, mYear, mMonth, mDay);
                picker.show();
            }
        });



    }











    private void createEmprunt()  {
        int noImmat = Integer.parseInt(etnoImmat.getText().toString().trim());
        int numVis = Integer.parseInt(etNumVis.getText().toString().trim());


        String depart = String.valueOf(etDateDep.getText().toString().trim() );
        String arriver = String.valueOf(etDateArr.getText().toString().trim() );


        System.out.print(depart);
        System.out.print(arriver);




        HashMap<String, String> params = new HashMap<>();
        params.put("dateDep", depart);
        params.put("dateArr", arriver);
        params.put("noImmat", String.valueOf(noImmat));
        params.put("numVis", String.valueOf(numVis));


        PerformNetworkRequest request = new PerformNetworkRequest(Api.URL_CREATE_EMPRUNT, params, CODE_POST_REQUEST);
        request.execute();
    }




    // Les trois types utilisés par une tâche asynchrone sont les suivants: params,progress,result : Void,Void,String
    private class PerformNetworkRequest extends AsyncTask<Void, Void, String> {
        String url;
        HashMap<String, String> params;
        int requestCode;


        PerformNetworkRequest(String url, HashMap<String, String> params, int requestCode) {
            this.url = url;
            this.params = params;
            this.requestCode = requestCode;
        }



        //invoquée sur le thread de l'interface utilisateur avant l'exécution de la tâche.
        // Cette étape est normalement utilisée pour configurer la tâche,
        // par exemple en affichant une barre de progression dans l'interface utilisateur.
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
         }

        //invoquée sur le thread de l'interface utilisateur après la fin du calcul de l'arrière-plan.
        // Le résultat du calcul de l'arrière-plan est passé à cette étape en tant que paramètre.
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
             try {

                JSONObject object = new JSONObject(s);

                if (!object.getBoolean("error")) {
                    Toast.makeText(getApplicationContext(), object.getString("message"), Toast.LENGTH_SHORT).show();
                 }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }


        //invoquée sur le thread d'arrière-plan immédiatement après la onPreExecute()fin de l'exécution.
// Cette étape est utilisée pour effectuer un calcul en arrière-plan qui peut prendre beaucoup de temps.
// Les paramètres de la tâche asynchrone sont transmis à cette étape.
// Le résultat du calcul doit être retourné par cette étape et sera renvoyé à la dernière étape.
        @Override
        protected String doInBackground(Void... voids) {
            RequestHandler requestHandler = new RequestHandler();

            if (requestCode == CODE_POST_REQUEST)
                return requestHandler.sendPostRequest(url, params);


            if (requestCode == CODE_GET_REQUEST)
                return requestHandler.sendGetRequest(url);

            return null;
        }
    }
}