package com.example.utilisateur.snapchatpro.modele;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Samy on 01/04/2018.
 */

public class OptionVehicule extends AppCompatActivity{    private Integer idMarque;
    private String libelle;
    private String type;
    private Integer libre;
    private String libelle2;
    private  float prix;

    public OptionVehicule(Integer idMarque, String libelle, String type, Integer libre,String libelle2, float prix) {
        this.idMarque = idMarque;
        this.libelle = libelle;
        this.type = type;
        this.libre=libre;
        this.libelle2 = libelle2;
        this.prix = prix;
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }


    public Integer getIdMarque() {
        return idMarque;
    }

    public String getLibelle() {
        return libelle;
    }

    public String getType() {
        return type;
    }


    public Integer getLibre() {
        return libre;
    }


    public  String getLibelle2() {
        return libelle2;
    }




    public  float getPrix() {
        return prix;
    }


    public  void setIdMarque (Integer idMarque){
        this.idMarque=idMarque;
    }






}