package com.example.utilisateur.snapchatpro.outils;


/**
 * Created by Samy on 16/03/2018.
 */

public abstract class Api {
    private static final String ROOT_URL = "http://192.168.1.22/snapAndroidApp/v2/Api.php?apicall=";

    public static final String URL_CREATE_VEHICULE = ROOT_URL + "createvehicule";
    public static final String URL_READ_VEHICULE = ROOT_URL + "getvehicule";
    public static final String URL_UPDATE_VEHICULE = ROOT_URL + "updatevehicule";
    public static final String URL_DELETE_VEHICULE = ROOT_URL + "deletevehicule&idMarque=";
    public static final String URL_CREATE_VISITEUR = ROOT_URL + "createvisiteur";
    public static final String URL_READ_SPINNER_LIBELLE = ROOT_URL +"getoptionlibelleprix";
      public static final String URL_RECHERCHE_VISITEUR= ROOT_URL + "recherchevisiteur";
    public static final String URL_READ_OPTION_VEHICULE = ROOT_URL + "getoptionvehicule";
    public static final String URL_CREATE_EMPRUNT = ROOT_URL + "createemprunt";


    //Messagerie
    public static final String URL_REGISTER_VISITEURS = "http://192.168.1.22/snapAndroidApp/includes/RegisterVisiteur.php";
    public static final String URL_SEND_SINGLE_PUSH = "http://192.168.1.22/snapAndroidApp/includes/sendSinglePush.php";
    public static final String URL_SEND_MULTIPLE_PUSH = "http://192.168.1.22/snapAndroidApp/includes/sendMultiplePush.php";
    public static final String URL_FETCH_VISITEURS = "http://192.168.1.22/snapAndroidApp/includes/GetRegisteredVisiteurs.php";




}
