package com.example.utilisateur.snapchatpro.view;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.WindowManager;

import com.example.utilisateur.snapchatpro.modele.Camera_Fragment;
import com.example.utilisateur.snapchatpro.modele.ChatFragment;
import com.example.utilisateur.snapchatpro.R;
import com.example.utilisateur.snapchatpro.modele.StoryFragment;
import com.example.utilisateur.snapchatpro.modele.UserInformation;

//import static com.example.utilisateur.snapchatpro.modele.Crud_Fragment.newInstance;


public class MainActivity extends AppCompatActivity {


    FragmentPagerAdapter adapterViewPager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        android.support.v7.app.ActionBar actionBar =  getSupportActionBar();
        actionBar.hide();






        UserInformation userInformationListener = new UserInformation();
        userInformationListener.startFetching();

        ViewPager viewPager = findViewById(R.id.viewPager);

        adapterViewPager = new MyPageAdapter(getSupportFragmentManager());
        viewPager.setAdapter(adapterViewPager);

        viewPager.setCurrentItem(1);
        // pour montrer la page camera en premier
    }

    public static class MyPageAdapter  extends FragmentPagerAdapter{


        public MyPageAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
           switch (position){
               case 0:
                   return ChatFragment.newInstance();
                   //retourne fragement chat
               case 1:
                   return Camera_Fragment.newInstance();
               //retourne fragement camera

               case 2:
                   return StoryFragment.newInstance();
            }
            return null;
        }

        @Override
        public int getCount() {
            return 3;
        }
        //3 pour le nombre de page
    }
}
