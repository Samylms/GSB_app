package com.example.utilisateur.snapchatpro.modele;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.utilisateur.snapchatpro.R;
import com.example.utilisateur.snapchatpro.outils.Api;
import com.example.utilisateur.snapchatpro.outils.RequestHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static android.view.View.GONE;

public class Crud_Fragment extends AppCompatActivity {

    private static final int CODE_GET_REQUEST = 1024;
    private static final int CODE_POST_REQUEST = 1025;

    public static Crud_Fragment newInstance(){
        Crud_Fragment fragment = new Crud_Fragment();
        return fragment;
    }

     EditText etidmarque,etlibelle,ettype,etlibre;
    Button buttonAdd;
    ProgressBar progressBar;
    ListView listView;

    List<Vehicule> vehiculeList;
    boolean isUpdating = false;


    // String string_noImmat,string_marque,string_type ,string_libre;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_crud);
        android.support.v7.app.ActionBar actionBar =  getSupportActionBar();
        actionBar.hide();

        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        etidmarque = (EditText)findViewById(R.id.txtNumMarque);
        etlibelle = (EditText)findViewById(R.id.txtMarque);
        ettype  = (EditText)findViewById(R.id.txtType);
        etlibre  = (EditText)findViewById(R.id.txtlibre);

        buttonAdd = (Button)findViewById(R.id.btnEnreg2);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        listView = (ListView) findViewById(R.id.listViewVehicules);

        vehiculeList = new ArrayList<>();

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isUpdating) {
                    updateVehicule();
                } else {
                    createVehicule();
                }

                //GetData();
                //InsertData(string_noImmat, string_marque,string_type,string_libre);

            }
        });
        readVehicule();
    }

    private void createVehicule() {
        int idMarque = Integer.parseInt(etidmarque.getText().toString().trim());
        String libelle = etlibelle.getText().toString().trim();
        String type = ettype.getText().toString().trim();
        int libre = Integer.parseInt(etlibre.getText().toString().trim());

        if (TextUtils.isEmpty(libelle)) {
            etlibelle.setError(" Entrer une marque");
            etlibelle.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(type)) {
            ettype.setError("Entrer un type");
            ettype.requestFocus();
            return;
        }

        HashMap<String, String> params = new HashMap<>();
        params.put("idMarque", String.valueOf(idMarque));
        params.put("libelle", libelle);
        params.put("type", type);
        params.put("libre", String.valueOf(libre));

        PerformNetworkRequest request = new PerformNetworkRequest(Api.URL_CREATE_VEHICULE, params, CODE_POST_REQUEST);
        request.execute();
    }

    private void readVehicule() {
        PerformNetworkRequest request = new PerformNetworkRequest(Api.URL_READ_VEHICULE, null, CODE_GET_REQUEST);
        request.execute();
    }


    private void updateVehicule() {
        int idMarque = Integer.parseInt(etidmarque.getText().toString().trim());
        String libelle = etlibelle.getText().toString().trim();
        String type = ettype.getText().toString().trim();
        int libre = Integer.parseInt(etlibre.getText().toString());


        if (TextUtils.isEmpty(libelle)) {
            etlibelle.setError("Entrer une marque");
            etlibelle.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(type)) {
            ettype.setError("Entrer un type");
            ettype.requestFocus();
            return;
        }

        HashMap<String, String> params = new HashMap<>();
        params.put("idMarque", String.valueOf(idMarque));
        params.put("libelle", libelle);
        params.put("type", type);
        params.put("libre", String.valueOf(libre));


        PerformNetworkRequest request = new PerformNetworkRequest(Api.URL_UPDATE_VEHICULE, params, CODE_POST_REQUEST);
        request.execute();

        buttonAdd.setText("Ajouter un véhicule");

        etidmarque.setText("");
        etlibelle.setText("");
        ettype.setText("");
        etlibre.setText("");



        isUpdating = false;
    }

    private void deleteVehicule(int idMarque) {
        PerformNetworkRequest request = new PerformNetworkRequest(Api.URL_DELETE_VEHICULE + idMarque, null, CODE_GET_REQUEST);
        request.execute();
    }

    private void refreshVehiculeList(JSONArray vehicules) throws JSONException {
        vehiculeList.clear();

        for (int i = 0; i < vehicules.length(); i++) {
            JSONObject obj = vehicules.getJSONObject(i);

            vehiculeList.add(new Vehicule(
                    obj.getInt("idMarque"),
                    obj.getString("libelle"),
                    obj.getString("type"),
                    obj.getInt("libre")
            ));
        }

        VehiculeAdapter adapter = new VehiculeAdapter(vehiculeList);
        listView.setAdapter(adapter);
    }

    // Les trois types utilisés par une tâche asynchrone sont les suivants: params,progress,result : Void,Void,String
    private class PerformNetworkRequest extends AsyncTask<Void, Void, String> {
        String url;
        HashMap<String, String> params;
        int requestCode;


        PerformNetworkRequest(String url, HashMap<String, String> params, int requestCode) {
            this.url = url;
            this.params = params;
            this.requestCode = requestCode;
        }



        //invoquée sur le thread de l'interface utilisateur avant l'exécution de la tâche.
        // Cette étape est normalement utilisée pour configurer la tâche,
        // par exemple en affichant une barre de progression dans l'interface utilisateur.
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
        }

        //invoquée sur le thread de l'interface utilisateur après la fin du calcul de l'arrière-plan.
        // Le résultat du calcul de l'arrière-plan est passé à cette étape en tant que paramètre.
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressBar.setVisibility(GONE);
            try {

                JSONObject object = new JSONObject(s);

                if (!object.getBoolean("error")) {
                    Toast.makeText(getApplicationContext(), object.getString("message"), Toast.LENGTH_SHORT).show();
                    refreshVehiculeList(object.getJSONArray("vehicules"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }


//invoquée sur le thread d'arrière-plan immédiatement après la onPreExecute()fin de l'exécution.
// Cette étape est utilisée pour effectuer un calcul en arrière-plan qui peut prendre beaucoup de temps.
// Les paramètres de la tâche asynchrone sont transmis à cette étape.
// Le résultat du calcul doit être retourné par cette étape et sera renvoyé à la dernière étape.
        @Override
        protected String doInBackground(Void... voids) {
            RequestHandler requestHandler = new RequestHandler();

            if (requestCode == CODE_POST_REQUEST)
                return requestHandler.sendPostRequest(url, params);


            if (requestCode == CODE_GET_REQUEST)
                return requestHandler.sendGetRequest(url);

            return null;
        }
    }








     class VehiculeAdapter extends ArrayAdapter<Vehicule> {
         List<Vehicule> vehiculeList;


         public VehiculeAdapter(List<Vehicule> vehiculeList) {
             super(Crud_Fragment.this, R.layout.layout_vehicule_list, vehiculeList);
             this.vehiculeList = vehiculeList;
         }


         @Override
         public View getView(int position, View convertView, ViewGroup parent) {
             LayoutInflater inflater = getLayoutInflater();
              View listViewItem = inflater.inflate(R.layout.layout_vehicule_list, null, true);

             TextView textViewName = listViewItem.findViewById(R.id.textViewName);
             TextView  textViewType= listViewItem.findViewById(R.id.textViewType);

             TextView textViewUpdate = listViewItem.findViewById(R.id.textViewUpdate);
             TextView textViewDelete = listViewItem.findViewById(R.id.textViewDelete);

             final Vehicule vehicule = vehiculeList.get(position);

             textViewName.setText(vehicule.getLibelle());
             textViewType.setText(vehicule.getType());


             textViewUpdate.setOnClickListener(new View.OnClickListener() {
                 @Override
                 public void onClick(View view) {
                     isUpdating = true;
                     etidmarque.setText(String.valueOf(vehicule.getIdMarque()));
                     etlibelle.setText(vehicule.getLibelle());
                     ettype.setText(vehicule.getType());
                     etlibre.setText(String.valueOf(vehicule.getLibre()));
                      buttonAdd.setText("Update");
                 }
             });

             textViewDelete.setOnClickListener(new View.OnClickListener() {
                 @Override
                 public void onClick(View view) {

                     AlertDialog.Builder builder = new AlertDialog.Builder(Crud_Fragment.this);

                     builder.setTitle("supprimer " + vehicule.getIdMarque())
                             .setMessage("Etes vous sure de vouloir supprimer ?")
                             .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                 public void onClick(DialogInterface dialog, int which) {
                                     deleteVehicule(vehicule.getIdMarque());
                                 }
                             })
                             .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                                 public void onClick(DialogInterface dialog, int which) {

                                 }
                             })
                             .setIcon(android.R.drawable.ic_dialog_alert)
                             .show();

                 }
             });

             return listViewItem;
         }
     }




}