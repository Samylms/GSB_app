package com.example.utilisateur.snapchatpro.recyclerViewReceiver;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import com.example.utilisateur.snapchatpro.R;

/**
 * Created by Samy on 20/03/2018.
 */

public class ReceiverViewHolders extends RecyclerView.ViewHolder{

    public TextView mEmail;
    public Button mFollow;
    public CheckBox mReceive;

    public ReceiverViewHolders(View itemView){
        super(itemView);
        mEmail=itemView.findViewById(R.id.email);
        mFollow=itemView.findViewById(R.id.follow);
        mReceive=itemView.findViewById(R.id.receive);

    }

}
