package com.example.utilisateur.snapchatpro.modele;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

import com.example.utilisateur.snapchatpro.R;

import org.json.JSONArray;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by Samy on 09/03/2018.
 */

public class Vehicule extends AppCompatActivity {
    private Integer idMarque;
    private String libelle;
    private String type;
    private Integer libre;

    public Vehicule(Integer idMarque, String libelle, String type, Integer libre) {
        this.idMarque = idMarque;
        this.libelle = libelle;
        this.type = type;
        this.libre=libre;
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }


    public Integer getIdMarque() {
        return idMarque;
    }

    public String getLibelle() {
        return libelle;
    }

    public String getType() {
        return type;
    }


    public Integer getLibre() {
        return libre;
    }





}
