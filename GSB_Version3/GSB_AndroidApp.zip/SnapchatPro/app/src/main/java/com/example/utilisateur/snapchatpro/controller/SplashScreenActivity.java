package com.example.utilisateur.snapchatpro.controller;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.utilisateur.snapchatpro.view.ChooseLoginRegistrationActivity;
import com.example.utilisateur.snapchatpro.view.MainActivity;
import com.google.firebase.auth.FirebaseAuth;

/**
 * Created by Utilisateur on 24/01/2018.
 */

public class SplashScreenActivity extends AppCompatActivity {

    public static Boolean started = false;
    private FirebaseAuth mAuth;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    mAuth = FirebaseAuth.getInstance();
    if (mAuth.getCurrentUser()!= null){
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
        return;
    }else{
        Intent intent = new Intent(getApplicationContext(), ChooseLoginRegistrationActivity.class);
        intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
        return;

    }
    }
}
