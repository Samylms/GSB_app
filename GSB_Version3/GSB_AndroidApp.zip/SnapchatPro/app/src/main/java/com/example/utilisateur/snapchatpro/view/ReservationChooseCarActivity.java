package com.example.utilisateur.snapchatpro.view;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.utilisateur.snapchatpro.R;
import com.example.utilisateur.snapchatpro.modele.OptionVehicule;
import com.example.utilisateur.snapchatpro.modele.Vehicule;
import com.example.utilisateur.snapchatpro.outils.Api;
import com.example.utilisateur.snapchatpro.outils.RequestHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static android.view.View.GONE;

public class ReservationChooseCarActivity extends AppCompatActivity {

    private static final int CODE_GET_REQUEST = 1024;
    private static final int CODE_POST_REQUEST = 1025;

     Button buttonPayer;
    ProgressBar progressBar;
    ListView listView;
    List<OptionVehicule> vehiculeList;
     TextView   mTextNom,mTextPrenom,mTextNumVis;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        android.support.v7.app.ActionBar actionBar =  getSupportActionBar();
        actionBar.hide();
        setContentView(R.layout.activity_reservation_choose_car);



        buttonPayer = (Button) findViewById(R.id.btnPayer);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        listView = (ListView) findViewById(R.id.listViewVehicules2);

        mTextNumVis= (TextView) findViewById(R.id.txtNumVis2);
        mTextNom = (TextView) findViewById(R.id.txtNom2);
        mTextPrenom = (TextView) findViewById(R.id.txtPrenom2);


        mTextNumVis.setText(getIntent().getExtras().getString("numVis"));
        mTextNom.setText(getIntent().getExtras().getString("nom"));
        mTextPrenom.setText(getIntent().getExtras().getString("prenom"));

        vehiculeList = new ArrayList<>();
        buttonPayer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //  selectVehicule();

            }
        });
        readVehicule();
    }



    private void readVehicule() {
        ReservationChooseCarActivity.PerformNetworkRequest request = new PerformNetworkRequest(Api.URL_READ_OPTION_VEHICULE, null, CODE_GET_REQUEST);
        request.execute();
    }

    private void refreshVehiculeList(JSONArray vehicules) throws JSONException {
        vehiculeList.clear();

        for (int i = 0; i < vehicules.length(); i++) {
            JSONObject obj = vehicules.getJSONObject(i);

            vehiculeList.add(new OptionVehicule(
                    obj.getInt("idMarque"),
                    obj.getString("libelle"),
                    obj.getString("type"),
                    obj.getInt("libre"),
                    obj.getString("libelle2"),
                    (float) obj.getDouble("prix")
            ));
        }



        ReservationChooseCarActivity.VehiculeAdapter adapter = new VehiculeAdapter(vehiculeList);
        listView.setAdapter(adapter);
         listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {


             @Override
             public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                 OptionVehicule item = (OptionVehicule) adapter.getItem(i);
                 Intent intent = new Intent(ReservationChooseCarActivity.this, EmpruntActivity.class);

                  //recuperer les variable et les afficher dans une seconde activité
                 intent.putExtra("idMarque", item.getIdMarque());
                 intent.putExtra("libelle", item.getLibelle());
                  intent.putExtra("type", item.getType());
                 intent.putExtra("libelle2", item.getLibelle2());
                 intent.putExtra("prix", item.getPrix());


                  startActivity(intent);
             }
         });
    }



    // Les trois types utilisés par une tâche asynchrone sont les suivants: params,progress,result : Void,Void,String
    private class PerformNetworkRequest extends AsyncTask<Void, Void, String> {
        String url;
        HashMap<String, String> params;
        int requestCode;


        PerformNetworkRequest(String url, HashMap<String, String> params, int requestCode) {
            this.url = url;
            this.params = params;
            this.requestCode = requestCode;
        }


        //invoquée sur le thread de l'interface utilisateur avant l'exécution de la tâche.
        // Cette étape est normalement utilisée pour configurer la tâche,
        // par exemple en affichant une barre de progression dans l'interface utilisateur.
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
        }

        //invoquée sur le thread de l'interface utilisateur après la fin du calcul de l'arrière-plan.
        // Le résultat du calcul de l'arrière-plan est passé à cette étape en tant que paramètre.
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressBar.setVisibility(GONE);
            try {

                JSONObject object = new JSONObject(s);

                if (!object.getBoolean("error")) {
                    Toast.makeText(getApplicationContext(), object.getString("message"), Toast.LENGTH_SHORT).show();
                    refreshVehiculeList(object.getJSONArray("vehicules"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }


        //invoquée sur le thread d'arrière-plan immédiatement après la onPreExecute()fin de l'exécution.
// Cette étape est utilisée pour effectuer un calcul en arrière-plan qui peut prendre beaucoup de temps.
// Les paramètres de la tâche asynchrone sont transmis à cette étape.
// Le résultat du calcul doit être retourné par cette étape et sera renvoyé à la dernière étape.
        @Override
        protected String doInBackground(Void... voids) {
            RequestHandler requestHandler = new RequestHandler();

            if (requestCode == CODE_POST_REQUEST)
                return requestHandler.sendPostRequest(url, params);


            if (requestCode == CODE_GET_REQUEST)
                return requestHandler.sendGetRequest(url);

            return null;
        }
    }


    //pour afficher vehicule dans un listview
    class VehiculeAdapter extends ArrayAdapter<OptionVehicule> {
        List<OptionVehicule> vehiculeList;


        public VehiculeAdapter(List<OptionVehicule> vehiculeList) {
            super(ReservationChooseCarActivity.this, R.layout.layout_vehicule_list_res, vehiculeList);
            this.vehiculeList = vehiculeList;
        }


        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = getLayoutInflater();
            View listViewItem = inflater.inflate(R.layout.layout_vehicule_list_res, null, true);

            TextView textViewNoImmat = listViewItem.findViewById(R.id.textViewNoImmat);
            TextView textViewName = listViewItem.findViewById(R.id.textViewName2);
            TextView textViewType = listViewItem.findViewById(R.id.textViewType2);
            TextView textViewLibelle = listViewItem.findViewById(R.id.textViewLibelle);
            TextView textViewPrix = listViewItem.findViewById(R.id.textViewPrix);

            TextView textViewSelect = listViewItem.findViewById(R.id.textViewChoisir);

            final OptionVehicule vehicule = vehiculeList.get(position);

            textViewNoImmat.setText("id du vehicule : "+vehicule.getIdMarque());
            textViewName.setText(vehicule.getLibelle());
            textViewType.setText(vehicule.getType());
            textViewLibelle.setText("option : "+vehicule.getLibelle2());
            textViewPrix.setText(Double.toString(vehicule.getPrix())+" €");

             textViewSelect.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });


            return listViewItem;
        }


    }
}
